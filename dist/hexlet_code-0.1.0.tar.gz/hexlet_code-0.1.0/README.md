### Hexlet tests and linter status:
[![Actions Status](https://github.com/DmitryFedoreev/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DmitryFedoreev/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ca0660e14ccaa4f35e6a/maintainability)](https://codeclimate.com/github/DmitryFedoreev/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/ca0660e14ccaa4f35e6a/test_coverage)](https://codeclimate.com/github/DmitryFedoreev/python-project-50/test_coverage)
[![test](https://github.com/DmitryFedoreev/python-project-50/actions/workflows/test.yml/badge.svg)](https://github.com/DmitryFedoreev/python-project-50/actions/workflows/test.yml)


### Example of the program
[![asciicast](https://asciinema.org/a/666495.svg)](https://asciinema.org/a/666495)

### Format yml
[![asciicast](https://asciinema.org/a/666933.svg)](https://asciinema.org/a/666933)
