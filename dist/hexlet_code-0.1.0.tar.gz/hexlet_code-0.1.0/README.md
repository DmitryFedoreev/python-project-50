### Hexlet tests and linter status:
[![Actions Status](https://github.com/DmitryFedoreev/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DmitryFedoreev/python-project-50/actions)


### Example of the program
[![asciicast](https://asciinema.org/a/666495.svg)](https://asciinema.org/a/666495)